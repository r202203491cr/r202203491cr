#include <stdio.h>

int main() {
    char name[50];

    printf("あなたの名前を入力してください: ");
    scanf("%s", name);

    printf("こんにちは、%sさん！\n", name);

    return 0;
}
