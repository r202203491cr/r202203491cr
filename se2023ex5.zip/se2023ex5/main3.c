#include <stdio.h>

int main() {
    int num1, num2, sum;

    printf("最初の整数を入力してください: ");
    scanf("%d", &num1);

    printf("次の整数を入力してください: ");
    scanf("%d", &num2);

    sum = num1 + num2;

    printf("%d と %d の合計は %d です。\n", num1, num2, sum);

    return 0;
}
